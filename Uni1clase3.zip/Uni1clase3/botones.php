<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <title>Mi proyecto Php</title>
</head>
<body>
<div class="jumbotron text-center">
     <h1>SEMANA 3 Trabajando interfaces con Bootstrap</h1>
    <p> Este sitio incluye bootstrap y es un  ejemplo del diseño responsive.</p>
     </div>

    <br>
    <div class="container">
    <nav class="navbar navbar-expand-sm bg-dark">

    <!--Links-->
    <u1 class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="./index.php">Tablas</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./imagenes.php">Imagenes</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./alertas.php">Alertas</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Botones</a>
      </li>
      <li class="nav-item">
      <button type="button" class="btn btn-outline-primary">Primary</button>
      </li>
     </u1>  

     </nav> 
    </div>
    <br>
    <div class="container">
         <h1>EJEMPLO DE PROYECTO EN REPOSITORIO</h1>
        <h2>HOLA ESTE ES MI EJEMPLO TRABAJANDO CON BOTONES</h2> 
        <h3>ESTILO DE BOTONES</h3>
        <button type="button" class="btn">Basic</button>
        <button type="button" class="btn btn-primary">Primary
        <span class="spinner-border spinner-border-sm"></span>
        </button>
        <button type="button" class="btn btn-secondary">Secondary</button>
        <button type="button" class="btn btn-success">Success</button>
        <button type="button" class="btn btn-info">Info</button>
        <button type="button" class="btn btn-warning">Warning</button>
        <button type="button" class="btn btn-danger">Danger</button>
        <button type="button" class="btn btn-dark">Dark</button>
        <button type="button" class="btn btn-light">Light</button>
        <button type="button" class="btn btn-link">Link</button>
        <h3>ESTILO DE BOTONES</h3>
        <button type="button" class="btn btn-outline-primary">Primary</button>
        <button type="button" class="btn btn-outline-secondary">Secondary</button>
        <button type="button" class="btn btn-outline-success">Success</button>
        <button type="button" class="btn btn-outline-info">Info</button>
        <button type="button" class="btn btn-outline-warning">Warning</button>
        <button type="button" class="btn btn-outline-danger">Danger</button>
        <button type="button" class="btn btn-outline-dark">Dark</button>
        <button type="button" class="btn btn-outline-light text-dark">Light</button>

    </div>
</body>
</html>